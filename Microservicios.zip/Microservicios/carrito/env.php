; <?php exit; ?>
MYSQL_DATABASE_NAME = "carrito"
MYSQL_USER = "root"
MYSQL_PASSWORD = ""