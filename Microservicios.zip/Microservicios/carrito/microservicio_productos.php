<?php
// microservicio_productos.php
include_once "funciones.php";

function obtenerProductosParaMicroservicio() {
    // Mantiene la lógica existente de obtenerProductos() 
    $bd = obtenerConexion();
    $sentencia = $bd->query("SELECT id, nombre, descripcion, precio FROM productos");
    return $sentencia->fetchAll();
}
?>
